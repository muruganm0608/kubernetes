package com.jhooq.demo.Jhooqdockerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JhooqDockerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JhooqDockerDemoApplication.class, args);
	}

}
