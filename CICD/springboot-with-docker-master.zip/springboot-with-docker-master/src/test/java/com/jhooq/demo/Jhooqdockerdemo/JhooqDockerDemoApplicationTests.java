package com.jhooq.demo.Jhooqdockerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JhooqDockerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
